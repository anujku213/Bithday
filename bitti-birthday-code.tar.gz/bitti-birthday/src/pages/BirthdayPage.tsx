import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useAnimation } from 'framer-motion';
import { Heart, Play, Pause, Volume2, VolumeX, Sparkles, Gift, Star, Moon, QrCode, Lock, ChevronRight, Music, Camera, FastForward, SkipBack, SkipForward, Infinity as InfinityIcon } from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';

// Assets
import shivani1 from "@assets/shivani_1_1777403604731.jpeg";
import shivani2 from "@assets/shivani_2_1777403612857.jpeg";
import shivani3 from "@assets/shivani_3_1777403619354.jpeg";
import shivani4 from "@assets/shivani_4_1777403625663.jpeg";
import bdaySong from "@assets/bday_music_1777403662673.mp4";

export default function BirthdayPage() {
  const [stage, setStage] = useState<'entry' | 'password' | 'experience'>('entry');
  const [password, setPassword] = useState('');
  const [pwdError, setPwdError] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const handleUnlock = () => setStage('password');

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.toLowerCase().replace(/\s/g, '') === '13march') {
      setStage('experience');
      if (audioRef.current) {
        audioRef.current.volume = 0.5;
        audioRef.current.play().then(() => setIsPlaying(true)).catch(e => console.error("Audio play failed:", e));
      }
    } else {
      setPwdError(true);
      setTimeout(() => setPwdError(false), 1000);
    }
  };

  const toggleAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className="relative min-h-[100dvh] bg-[#05010d] text-white selection:bg-pink-500 selection:text-white font-sans overflow-x-hidden">
      <audio ref={audioRef} src={bdaySong} loop />
      
      {stage === 'experience' && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 2 }}
          className="fixed bottom-6 right-6 z-[100] flex gap-3"
        >
          <button onClick={toggleAudio} className="w-12 h-12 rounded-full glass-card flex items-center justify-center text-pink-400 hover:text-white transition-colors shadow-[0_0_15px_rgba(255,105,180,0.3)]">
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button onClick={toggleMute} className="w-12 h-12 rounded-full glass-card flex items-center justify-center text-pink-400 hover:text-white transition-colors shadow-[0_0_15px_rgba(255,105,180,0.3)]">
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
        </motion.div>
      )}

      <AnimatePresence mode="wait">
        {stage === 'entry' && (
          <motion.div 
            key="entry"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.1, filter: 'blur(10px)' }}
            transition={{ duration: 0.8 }}
            className="min-h-[100dvh] flex flex-col items-center justify-center p-6 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-pink-900/20 via-purple-900/10 to-transparent pointer-events-none" />
            
            {/* Floating Particles */}
            <Particles count={20} />

            <div className="glass-card p-10 rounded-3xl max-w-sm w-full text-center flex flex-col items-center gap-8 relative z-10 animate-pulse-glow">
              <div className="w-32 h-32 relative border-2 border-pink-500/50 rounded-xl overflow-hidden flex items-center justify-center bg-black/40 shadow-[0_0_20px_rgba(255,105,180,0.3)]">
                <motion.div 
                  animate={{ top: ['-10%', '110%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute left-0 right-0 h-[2px] bg-pink-400 shadow-[0_0_15px_#ff69b4]"
                />
                <QrCode size={64} className="text-pink-400 opacity-80" />
              </div>
              
              <div className="space-y-2">
                <h1 className="text-2xl font-serif font-bold neon-text">Scan to Unlock Your Surprise ❤️</h1>
                <p className="text-sm text-gray-400">A special delivery for someone special.</p>
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleUnlock}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 font-bold text-lg shadow-[0_0_20px_rgba(255,105,180,0.5)] hover:shadow-[0_0_30px_rgba(255,105,180,0.8)] transition-shadow text-white tracking-wide"
              >
                Tap to Unlock
              </motion.button>
            </div>
          </motion.div>
        )}

        {stage === 'password' && (
          <motion.div 
            key="password"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.5, filter: 'blur(20px)' }}
            transition={{ duration: 0.8 }}
            className="min-h-[100dvh] flex items-center justify-center p-6 relative"
          >
            <Particles count={20} />
            <motion.form 
              animate={pwdError ? { x: [-10, 10, -10, 10, 0] } : {}}
              transition={{ duration: 0.4 }}
              onSubmit={handlePasswordSubmit}
              className={`glass-card p-10 rounded-3xl max-w-sm w-full text-center space-y-8 z-10 ${pwdError ? 'border-red-500 shadow-[0_0_30px_rgba(255,0,0,0.3)]' : 'shadow-[0_0_20px_rgba(255,105,180,0.2)]'}`}
            >
              <div className="w-16 h-16 rounded-full bg-pink-500/20 mx-auto flex items-center justify-center mb-4 neon-border">
                <Lock size={32} className="text-pink-400 drop-shadow-[0_0_8px_rgba(255,105,180,0.8)]" />
              </div>
              
              <div className="space-y-3">
                <h2 className="text-3xl font-serif font-bold neon-text">Enter the Secret Date ❤️</h2>
                <p className="text-sm text-pink-300/70 italic">Hint: 13 March 🌹</p>
              </div>

              <div className="space-y-4">
                <input 
                  type="text" 
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="e.g. 13march"
                  className={`w-full bg-black/50 border rounded-xl px-4 py-3 text-center text-xl font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-pink-500 transition-all ${pwdError ? 'border-red-500 text-red-400' : 'border-pink-500/30 text-white'}`}
                />
                
                <div className="h-6">
                  <AnimatePresence>
                    {pwdError && (
                      <motion.p 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        className="text-red-400 text-sm font-hindi"
                      >
                        गलत तारीख़ है जान 💔 फिर से कोशिश करो
                      </motion.p>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-pink-600/80 to-purple-600/80 hover:from-pink-500 hover:to-purple-500 border border-pink-500/50 font-bold transition-all shadow-[0_0_15px_rgba(255,105,180,0.3)]"
              >
                Unlock My Heart
              </motion.button>
            </motion.form>
          </motion.div>
        )}

        {stage === 'experience' && (
          <motion.div 
            key="experience"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
          >
            <FullExperience isPlaying={isPlaying} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Particles({ count = 30 }: { count?: number }) {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute text-pink-500/30"
          initial={{ 
            x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000), 
            y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 1000),
            scale: Math.random() * 0.5 + 0.5,
            opacity: Math.random() * 0.5 + 0.2
          }}
          animate={{ 
            y: [null, Math.random() * -200 - 100],
            opacity: [null, 0]
          }}
          transition={{ 
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          <Heart size={Math.random() * 10 + 10} fill="currentColor" />
        </motion.div>
      ))}
    </div>
  );
}

function Section({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <section className={`relative w-full ${className}`}>
      {children}
    </section>
  );
}

function FullExperience({ isPlaying }: { isPlaying: boolean }) {
  const [showFinalPopup, setShowFinalPopup] = useState(false);
  const [candleBlown, setCandleBlown] = useState(false);

  return (
    <div className="w-full flex flex-col items-center">
      {/* 3. Cinematic Intro */}
      <Section className="min-h-[100dvh] flex items-center justify-center snap-center">
        <Particles count={40} />
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 2 }}
          className="text-center space-y-12 px-6 z-10"
        >
          <motion.h2 
            initial={{ opacity: 0, filter: 'blur(10px)' }}
            whileInView={{ opacity: 1, filter: 'blur(0px)' }}
            transition={{ duration: 2, delay: 1 }}
            className="text-3xl md:text-5xl font-hindi font-light leading-relaxed text-pink-100"
          >
            कुछ लोग ज़िंदगी बन जाते हैं...
          </motion.h2>
          <motion.h2 
            initial={{ opacity: 0, filter: 'blur(10px)' }}
            whileInView={{ opacity: 1, filter: 'blur(0px)' }}
            transition={{ duration: 2, delay: 3.5 }}
            className="text-4xl md:text-6xl lg:text-7xl font-hindi font-bold neon-text bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-pink-400 leading-normal pb-4"
          >
            और तुम मेरी सबसे खूबसूरत ज़िंदगी हो ❤️
          </motion.h2>
        </motion.div>
      </Section>

      {/* 4. AI Voice / Music Player */}
      <Section className="min-h-[100dvh] flex items-center justify-center snap-center px-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: false }}
          transition={{ duration: 1 }}
          className="glass-card max-w-md w-full p-8 rounded-3xl text-center space-y-8 relative overflow-hidden"
        >
          <div className="absolute top-[-50px] right-[-50px] w-32 h-32 bg-pink-500/20 rounded-full blur-2xl" />
          
          <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-pink-500 to-purple-600 p-1 shadow-[0_0_30px_rgba(255,105,180,0.5)]">
            <div className="w-full h-full bg-black/80 rounded-full flex items-center justify-center">
              <Music className="text-pink-400 w-12 h-12" />
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-serif font-bold text-white neon-text mb-2">Happy Birthday meri jaan Bitti ❤️</h3>
            <p className="text-pink-300/80 text-sm">Your Birthday Anthem</p>
          </div>

          <div className="flex items-center justify-center gap-2 h-12">
            {Array.from({ length: 20 }).map((_, i) => (
              <motion.div 
                key={i}
                animate={isPlaying ? { height: [10, Math.random() * 40 + 10, 10] } : { height: 4 }}
                transition={isPlaying ? { duration: 0.5, repeat: Infinity, delay: Math.random() * 0.5 } : {}}
                className="w-1.5 bg-pink-500 rounded-full shadow-[0_0_5px_#ff69b4]"
              />
            ))}
          </div>
        </motion.div>
      </Section>

      {/* 5 & 6. Birthday Scene & Candle */}
      <Section className="min-h-[100dvh] flex flex-col items-center justify-center snap-center relative">
        {candleBlown && <Confetti />}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="text-center space-y-16 z-10"
        >
          <h2 className="text-4xl md:text-6xl font-serif font-bold neon-text">Make a Wish 🎂</h2>
          
          <div className="relative w-64 h-64 mx-auto">
            {/* Cake Tiers */}
            <div className="absolute bottom-0 w-64 h-24 bg-gradient-to-r from-purple-800 to-pink-800 rounded-xl shadow-[0_10px_30px_rgba(255,105,180,0.3)] border-t-4 border-pink-400" />
            <div className="absolute bottom-24 left-8 w-48 h-20 bg-gradient-to-r from-pink-700 to-purple-700 rounded-xl shadow-lg border-t-4 border-pink-300" />
            <div className="absolute bottom-44 left-16 w-32 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl shadow-md border-t-4 border-pink-200" />
            
            {/* Candle */}
            <div className="absolute bottom-60 left-1/2 -translate-x-1/2 w-4 h-16 bg-gradient-to-b from-white to-pink-200 rounded-sm">
              {!candleBlown && (
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-6 h-8 bg-orange-400 rounded-full blur-[2px] animate-flicker shadow-[0_0_20px_#ffaa00]" style={{ borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%' }} />
              )}
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCandleBlown(true)}
            className="px-8 py-4 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 font-bold text-xl shadow-[0_0_20px_rgba(255,105,180,0.5)] border border-pink-400/50"
          >
            {candleBlown ? "Yay! 🎉" : "Blow Candle 💨"}
          </motion.button>
        </motion.div>
      </Section>

      {/* 7 & 8. Grand Celebration & Name Reveal */}
      <Section className="min-h-[100dvh] flex flex-col items-center justify-center snap-center overflow-hidden relative">
        <Particles count={50} />
        <div className="text-center z-10 px-4">
          <motion.h1 
            initial={{ scale: 0.5, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", bounce: 0.5, duration: 1 }}
            className="text-6xl md:text-8xl lg:text-9xl font-serif font-black mb-8 leading-tight text-transparent bg-clip-text bg-gradient-to-b from-pink-300 via-pink-500 to-purple-600 drop-shadow-[0_0_20px_rgba(255,105,180,0.5)]"
          >
            Happy Birthday
          </motion.h1>
          
          <div className="flex justify-center gap-2 md:gap-4 flex-wrap">
            {"BITTI".split("").map((letter, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 50, rotateX: -90 }}
                whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
                transition={{ duration: 0.8, delay: i * 0.2 }}
                className="text-7xl md:text-9xl font-bold neon-text inline-block"
                style={{ color: `hsl(${300 + i * 15}, 80%, 60%)` }}
              >
                {letter}
              </motion.span>
            ))}
          </div>
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 2 }}
            className="text-2xl md:text-4xl mt-12 font-hindi text-pink-200"
          >
            😘😘😘
          </motion.p>
        </div>
      </Section>

      {/* 9. Hindi Love Letter */}
      <Section className="min-h-[100dvh] py-20 flex items-center justify-center snap-center px-4">
        <motion.div 
          initial={{ opacity: 0, y: 50, rotateZ: -2 }}
          whileInView={{ opacity: 1, y: 0, rotateZ: 0 }}
          transition={{ duration: 1 }}
          className="glass-card max-w-3xl w-full p-8 md:p-14 rounded-lg relative overflow-hidden bg-gradient-to-br from-[#1a0b1a]/80 to-[#0a0510]/90 border-[1px] border-pink-500/30"
          style={{ boxShadow: '0 20px 50px rgba(0,0,0,0.5), inset 0 0 0 1px rgba(255,105,180,0.1)' }}
        >
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }} />
          
          <h3 className="text-5xl font-handwriting text-pink-400 mb-10 text-center drop-shadow-[0_2px_4px_rgba(255,105,180,0.4)]">मेरी प्यारी बिट्टी ❤️</h3>
          
          <div className="font-hindi text-xl md:text-3xl leading-relaxed space-y-8 text-pink-50 text-center">
            <TypewriterText text="तुम्हारी मुस्कान मेरी सबसे बड़ी खुशी है।" delay={0.5} />
            <TypewriterText text="तुम्हारा प्यार मेरी ज़िंदगी की सबसे खूबसूरत कहानी है।" delay={1.5} />
            <TypewriterText text="तुम मेरी दुनिया हो।" delay={2.5} />
            <motion.p 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 4, duration: 1 }}
              className="text-3xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-500 mt-12 pb-4 drop-shadow-[0_0_10px_rgba(255,105,180,0.3)]"
            >
              जन्मदिन मुबारक हो मेरी जान 😘
            </motion.p>
          </div>
        </motion.div>
      </Section>

      {/* 10. Hindi Romantic Notes (Embla Carousel) */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center">
        <h2 className="text-4xl md:text-5xl font-serif font-bold neon-text mb-16 text-center px-4">My Heart Says...</h2>
        <RomanticCarousel />
      </Section>

      {/* 11. Photo Gallery */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <h2 className="text-4xl md:text-5xl font-serif font-bold neon-text mb-16 text-center">Beautiful Memories 📸</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 max-w-6xl w-full">
          {[shivani1, shivani2, shivani3, shivani4].map((src, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.8, rotate: i % 2 === 0 ? -5 : 5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05, rotate: 0, zIndex: 10 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative aspect-[3/4] md:aspect-square group cursor-pointer"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-pink-500 to-purple-600 rounded-2xl blur-xl opacity-20 group-hover:opacity-60 transition-opacity duration-500" />
              <div className="relative w-full h-full bg-white p-3 md:p-4 pb-12 md:pb-16 rounded-2xl shadow-2xl overflow-hidden transform transition-transform">
                <img src={src} alt={`Memory ${i+1}`} className="w-full h-full object-cover rounded-xl" />
                <div className="absolute bottom-0 left-0 right-0 h-12 md:h-16 flex items-center justify-center font-handwriting text-2xl md:text-3xl text-gray-800">
                  Forever ❤️
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 12. Love Story Timeline */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <h2 className="text-4xl md:text-5xl font-serif font-bold neon-text mb-20 text-center">Our Journey 💫</h2>
        <div className="relative max-w-2xl w-full">
          <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-pink-500 via-purple-500 to-pink-500 shadow-[0_0_15px_#ff69b4]" />
          
          {[
            { year: "Day 1", title: "पहली बातचीत", desc: "The spark that started it all" },
            { year: "The Date", title: "पहली मुलाकात", desc: "When time stood still" },
            { year: "The Moment", title: "पहला 'I love you'", desc: "When my heart knew" },
            { year: "Forever", title: "हर पल साथ", desc: "Building our beautiful life" }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: false, amount: 0.5 }}
              transition={{ duration: 0.8 }}
              className={`relative flex items-center justify-between mb-16 ${i % 2 === 0 ? 'flex-row-reverse' : ''}`}
            >
              <div className="w-5/12" />
              <div className="absolute left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-pink-500 border-4 border-[#05010d] shadow-[0_0_15px_#ff69b4] z-10" />
              <div className={`w-5/12 glass-card p-6 rounded-2xl ${i % 2 === 0 ? 'text-right' : 'text-left'}`}>
                <span className="text-pink-400 font-bold tracking-widest text-sm uppercase">{item.year}</span>
                <h4 className="text-2xl font-hindi font-bold text-white mt-2 mb-1">{item.title}</h4>
                <p className="text-gray-400 text-sm">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* 13. Reasons Why I Love You */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <h2 className="text-4xl md:text-5xl font-serif font-bold neon-text mb-16 text-center">Reasons I Love You 💖</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-8 max-w-4xl w-full">
          {[
            { front: "तुम्हारी मुस्कान", back: "जो मेरे दिन को रोशन कर देती है" },
            { front: "तुम्हारा दिल", back: "जो सबसे साफ़ और प्यारा है" },
            { front: "तुम्हारी मासूमियत", back: "जिसपर मुझे प्यार आता है" },
            { front: "तुम्हारा साथ", back: "जो मुझे हिम्मत देता है" },
            { front: "तुम्हारी आँखें", back: "जिनमें मैं डूब जाना चाहता हूँ" },
            { front: "तुम्हारी बातें", back: "जो मुझे सुकून देती हैं" }
          ].map((item, i) => (
            <FlipCard key={i} front={item.front} back={item.back} delay={i * 0.1} />
          ))}
        </div>
      </Section>

      {/* 14. Love Quiz */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <LoveQuiz />
      </Section>

      {/* 15. Secret Gift Box */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <SecretGift />
      </Section>

      {/* 16. Spotify Playlist */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <Playlist />
      </Section>

      {/* 17 & 18. Timers */}
      <Section className="min-h-[100dvh] py-20 flex flex-col items-center justify-center snap-center px-4 space-y-24">
        <LoveTimer />
        <BirthdayCountdown />
      </Section>

      {/* 19. Virtual Hug / Kiss */}
      <Section className="min-[70vh] py-20 flex flex-col items-center justify-center snap-center px-4">
        <h2 className="text-4xl md:text-5xl font-serif font-bold neon-text mb-16 text-center">Sending My Love 💌</h2>
        <VirtualActions />
      </Section>

      {/* 20. Starry Night Scene */}
      <Section className="min-h-[100dvh] flex flex-col items-center justify-center snap-center px-4 relative overflow-hidden bg-black/80">
        <StarryNight />
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, delay: 0.5 }}
          className="z-10 text-center"
        >
          <Moon size={80} className="text-yellow-100 mx-auto mb-8 drop-shadow-[0_0_30px_rgba(255,255,200,0.8)] animate-pulse" fill="currentColor" />
          <h2 className="text-4xl md:text-6xl font-hindi font-bold text-white drop-shadow-lg max-w-3xl leading-relaxed">
            तुम मेरे आसमान का सबसे चमकीला तारा हो ✨
          </h2>
        </motion.div>
      </Section>

      {/* 21. Final Ending */}
      <Section className="min-h-[100dvh] flex flex-col items-center justify-center snap-center relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div 
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="w-full max-w-3xl aspect-square rounded-full bg-pink-600/10 blur-[100px]"
          />
        </div>
        
        <motion.div 
          initial={{ scale: 0 }}
          whileInView={{ scale: 1 }}
          transition={{ type: "spring", duration: 1.5 }}
          className="z-10 cursor-pointer"
          onClick={() => setShowFinalPopup(true)}
        >
          <Heart className="w-48 h-48 md:w-64 md:h-64 text-pink-500 animate-pulse-glow" fill="currentColor" />
        </motion.div>
        
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 1 }}
          className="text-5xl md:text-7xl font-hindi font-bold neon-text mt-12 z-10"
        >
          हमेशा तुम्हारा ❤️
        </motion.h2>
        
        <p className="mt-8 text-pink-300/50 text-sm z-10 animate-pulse">Tap the heart...</p>
      </Section>

      {/* 22. Final Surprise Popup */}
      <AnimatePresence>
        {showFinalPopup && <FinalPopup onClose={() => setShowFinalPopup(false)} />}
      </AnimatePresence>
    </div>
  );
}

function TypewriterText({ text, delay }: { text: string, delay: number }) {
  return (
    <motion.p
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ delay, duration: 0.5 }}
      viewport={{ once: true }}
    >
      {text.split("").map((char, i) => (
        <motion.span
          key={i}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: delay + i * 0.05 }}
          viewport={{ once: true }}
        >
          {char}
        </motion.span>
      ))}
    </motion.p>
  );
}

function RomanticCarousel() {
  const [emblaRef] = useEmblaCarousel({ loop: true, dragFree: true });
  const notes = [
    "तुम मेरी दुनिया हो ❤️",
    "तुम्हारे बिना सब अधूरा है 😘",
    "तुम मेरी सबसे प्यारी खुशी हो 🌸",
    "तेरी हँसी में मेरा सुकून है 💖",
    "तुम मेरी हर दुआ का जवाब हो 🌹"
  ];

  return (
    <div className="w-full max-w-lg overflow-hidden px-4" ref={emblaRef}>
      <div className="flex touch-pan-y">
        {notes.map((note, i) => (
          <div key={i} className="flex-[0_0_80%] min-w-0 pl-4 md:pl-6 first:pl-0">
            <div className="glass-card aspect-square rounded-3xl p-8 flex items-center justify-center text-center shadow-[0_10px_30px_rgba(255,105,180,0.2)] border border-pink-500/30 bg-gradient-to-br from-pink-900/30 to-purple-900/30">
              <h4 className="text-3xl md:text-4xl font-hindi font-bold text-pink-100 leading-snug neon-text">{note}</h4>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function FlipCard({ front, back, delay }: { front: string, back: string, delay: number }) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      className="perspective-1000 h-40 md:h-48 cursor-pointer"
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div 
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: "spring" }}
        className="w-full h-full relative preserve-3d"
      >
        <div className="absolute inset-0 backface-hidden glass-card rounded-2xl flex items-center justify-center p-4 text-center border border-pink-500/20 hover:border-pink-500/50 transition-colors">
          <h4 className="text-xl md:text-2xl font-hindi font-bold text-white">{front}</h4>
        </div>
        <div className="absolute inset-0 backface-hidden glass-card rounded-2xl flex items-center justify-center p-4 text-center bg-gradient-to-br from-pink-600/40 to-purple-600/40 border border-pink-400 rotate-y-180">
          <p className="text-lg md:text-xl font-hindi text-white drop-shadow-md">{back}</p>
        </div>
      </motion.div>
    </motion.div>
  );
}

function LoveQuiz() {
  const [step, setStep] = useState(0);
  const [error, setError] = useState(false);
  const [completed, setCompleted] = useState(false);

  const questions = [
    {
      q: "हमारी पहली डेट कहाँ हुई थी? ☕",
      options: ["Coffee Shop", "Park", "Movie Theater", "Restaurant"],
      ans: 0
    },
    {
      q: "मुझे तुम्हारी कौन सी चीज़ सबसे ज़्यादा पसंद है? 😍",
      options: ["तुम्हारी आँखें", "तुम्हारी स्माइल", "तुम्हारी बातें", "सब कुछ!"],
      ans: 3
    }
  ];

  const handleAnswer = (index: number) => {
    if (index === questions[step].ans) {
      if (step < questions.length - 1) {
        setStep(step + 1);
      } else {
        setCompleted(true);
      }
    } else {
      setError(true);
      setTimeout(() => setError(false), 1000);
    }
  };

  if (completed) {
    return (
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="glass-card max-w-lg w-full p-10 rounded-3xl text-center space-y-6"
      >
        <Sparkles className="w-16 h-16 mx-auto text-pink-400 animate-pulse" />
        <h3 className="text-3xl font-hindi font-bold neon-text">तुम मुझे बहुत अच्छे से जानती हो! 😘</h3>
        <p className="text-xl text-gray-300">Scroll down for your next surprise.</p>
      </motion.div>
    );
  }

  return (
    <div className="glass-card max-w-lg w-full p-8 md:p-10 rounded-3xl relative">
      <h2 className="text-3xl font-serif font-bold neon-text mb-8 text-center">Love Quiz 📝</h2>
      
      <AnimatePresence mode="wait">
        <motion.div 
          key={step}
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -50, opacity: 0 }}
          className="space-y-8"
        >
          <h3 className="text-2xl font-hindi text-white text-center">{questions[step].q}</h3>
          
          <div className="grid grid-cols-1 gap-4">
            {questions[step].options.map((opt, i) => (
              <motion.button
                key={i}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleAnswer(i)}
                animate={error ? { x: [-5, 5, -5, 5, 0] } : {}}
                className={`py-4 px-6 rounded-xl text-lg font-hindi transition-colors border ${error ? 'border-red-500 bg-red-500/20' : 'border-pink-500/30 bg-white/5 hover:bg-pink-500/20'}`}
              >
                {opt}
              </motion.button>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>

      {error && <p className="text-center text-red-400 mt-4 font-hindi">अरे बुद्धू! फिर से सोचो 😜</p>}
    </div>
  );
}

function SecretGift() {
  const [opened, setOpened] = useState(false);

  return (
    <div className="text-center space-y-12">
      <h2 className="text-4xl md:text-5xl font-serif font-bold neon-text">A Special Gift 🎁</h2>
      
      <div className="relative w-64 h-64 mx-auto flex items-center justify-center cursor-pointer" onClick={() => setOpened(true)}>
        {!opened ? (
          <motion.div 
            whileHover={{ rotate: [-5, 5, -5, 5, 0] }}
            className="text-pink-500 drop-shadow-[0_0_30px_rgba(255,105,180,0.8)]"
          >
            <Gift size={150} />
            <p className="mt-4 font-bold tracking-widest text-pink-300">TAP TO OPEN</p>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <div className="glass-card p-8 rounded-2xl border-2 border-pink-500 shadow-[0_0_50px_rgba(255,105,180,0.6)]">
              <h3 className="text-3xl font-hindi font-bold neon-text">तुम ही मेरा सबसे बड़ा तोहफा हो ❤️</h3>
            </div>
            <Confetti />
          </motion.div>
        )}
      </div>
    </div>
  );
}

function Playlist() {
  const songs = [
    { title: "Tum Hi Ho", artist: "Arijit Singh", time: "4:22" },
    { title: "Tera Ban Jaunga", artist: "Akhil Sachdeva", time: "3:56" },
    { title: "Kaise Hua", artist: "Vishal Mishra", time: "3:49" },
    { title: "Raabta", artist: "Arijit Singh", time: "4:03" },
    { title: "Tum Mile", artist: "Neeraj Shridhar", time: "5:44" }
  ];

  return (
    <div className="glass-card max-w-2xl w-full p-6 md:p-10 rounded-3xl border border-gray-800/50">
      <div className="flex items-center gap-4 mb-10">
        <div className="w-24 h-24 rounded-xl bg-gradient-to-br from-pink-500 to-purple-700 flex items-center justify-center shadow-lg">
          <Heart className="w-10 h-10 text-white" fill="currentColor" />
        </div>
        <div>
          <p className="text-sm font-bold text-gray-400 tracking-widest uppercase">Playlist</p>
          <h2 className="text-3xl md:text-5xl font-bold text-white mt-1">Our Songs ❤️</h2>
          <p className="text-gray-400 mt-2">Bitti & Me • {songs.length} songs</p>
        </div>
      </div>

      <div className="space-y-2">
        {songs.map((song, i) => (
          <div key={i} className="flex items-center justify-between p-3 md:p-4 hover:bg-white/5 rounded-xl group transition-colors cursor-pointer">
            <div className="flex items-center gap-4">
              <span className="text-gray-500 font-mono w-4 text-right group-hover:hidden">{i + 1}</span>
              <Play className="w-4 h-4 text-pink-500 hidden group-hover:block" />
              <div className="w-10 h-10 bg-gradient-to-br from-gray-800 to-gray-900 rounded bg-cover bg-center border border-gray-700" />
              <div>
                <p className="font-bold text-gray-200 group-hover:text-pink-400 transition-colors">{song.title}</p>
                <p className="text-sm text-gray-500">{song.artist}</p>
              </div>
            </div>
            <div className="flex items-center gap-6 text-gray-500">
              <Heart className="w-4 h-4 hover:text-pink-500 transition-colors hidden md:block" />
              <span className="font-mono text-sm">{song.time}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LoveTimer() {
  const [time, setTime] = useState({ y: 0, m: 0, d: 0, h: 0, min: 0, s: 0 });

  useEffect(() => {
    const startDate = new Date('2023-03-13T00:00:00').getTime();
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const diff = now - startDate;
      
      const y = Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
      const m = Math.floor((diff % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24 * 30.44));
      const d = Math.floor((diff % (1000 * 60 * 60 * 24 * 30.44)) / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const min = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      setTime({ y, m, d, h, min, s });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center w-full max-w-4xl">
      <h2 className="text-3xl md:text-4xl font-serif font-bold text-pink-300 mb-10">Time we've been in love 💕</h2>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
        {[
          { label: 'साल', val: time.y },
          { label: 'महीने', val: time.m },
          { label: 'दिन', val: time.d },
          { label: 'घंटे', val: time.h },
          { label: 'मिनट', val: time.min },
          { label: 'सेकंड', val: time.s }
        ].map((item, i) => (
          <div key={i} className="glass-card p-4 rounded-2xl flex flex-col items-center justify-center border border-pink-500/20">
            <span className="text-3xl md:text-5xl font-mono font-bold neon-text">{item.val}</span>
            <span className="text-gray-400 font-hindi mt-2 text-sm md:text-base">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function BirthdayCountdown() {
  const [time, setTime] = useState({ d: 0, h: 0, min: 0, s: 0 });

  useEffect(() => {
    const calculateNextBday = () => {
      const now = new Date();
      let nextBday = new Date(now.getFullYear(), 2, 13); // Month is 0-indexed, 2 = March
      
      if (now.getTime() > nextBday.getTime()) {
        nextBday.setFullYear(now.getFullYear() + 1);
      }
      return nextBday.getTime();
    };

    const target = calculateNextBday();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const diff = target - now;
      
      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const min = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      setTime({ d, h, min, s });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="text-center w-full max-w-2xl">
      <h2 className="text-2xl md:text-3xl font-serif font-bold text-purple-300 mb-8">Next Birthday In... 🎂</h2>
      <div className="flex justify-center gap-4 md:gap-8">
        {[
          { label: 'DAYS', val: time.d },
          { label: 'HOURS', val: time.h },
          { label: 'MINS', val: time.min },
          { label: 'SECS', val: time.s }
        ].map((item, i) => (
          <div key={i} className="flex flex-col items-center">
            <div className="bg-black/80 border-2 border-purple-500/50 rounded-xl w-16 h-20 md:w-24 md:h-28 flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.3)] relative overflow-hidden">
              <div className="absolute top-1/2 w-full h-[1px] bg-purple-500/30" />
              <span className="text-3xl md:text-5xl font-mono font-bold text-purple-400 drop-shadow-[0_0_8px_#a855f7]">{item.val.toString().padStart(2, '0')}</span>
            </div>
            <span className="text-gray-500 font-bold tracking-widest text-xs md:text-sm mt-4">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function VirtualActions() {
  const [actions, setActions] = useState<{id: number, type: 'hug' | 'kiss', x: number, y: number}[]>([]);
  let counter = useRef(0);

  const handleAction = (type: 'hug' | 'kiss', e: React.MouseEvent) => {
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top;
    
    // Create multiple particles
    const newActions = Array.from({ length: 5 }).map(() => ({
      id: counter.current++,
      type,
      x: x + (Math.random() * 100 - 50),
      y: y + (Math.random() * 50 - 25)
    }));
    
    setActions(prev => [...prev, ...newActions]);
    
    setTimeout(() => {
      setActions(prev => prev.filter(a => !newActions.find(na => na.id === a.id)));
    }, 2000);
  };

  return (
    <div className="flex gap-6 md:gap-10 relative">
      <button 
        onClick={(e) => handleAction('hug', e)}
        className="w-32 h-32 md:w-48 md:h-48 rounded-full glass-card border-2 border-pink-500/50 flex flex-col items-center justify-center gap-2 hover:bg-pink-500/20 hover:scale-105 active:scale-95 transition-all"
      >
        <span className="text-4xl md:text-6xl">🤗</span>
        <span className="font-bold text-pink-300">Virtual Hug</span>
      </button>

      <button 
        onClick={(e) => handleAction('kiss', e)}
        className="w-32 h-32 md:w-48 md:h-48 rounded-full glass-card border-2 border-red-500/50 flex flex-col items-center justify-center gap-2 hover:bg-red-500/20 hover:scale-105 active:scale-95 transition-all"
      >
        <span className="text-4xl md:text-6xl">😘</span>
        <span className="font-bold text-red-300">Send Kiss</span>
      </button>

      {/* Action Particles */}
      {actions.map(action => (
        <motion.div
          key={action.id}
          initial={{ opacity: 1, scale: 0.5, x: 0, y: 0 }}
          animate={{ 
            opacity: 0, 
            scale: 2, 
            y: -200 - Math.random() * 100,
            x: (Math.random() - 0.5) * 200
          }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="fixed z-50 pointer-events-none text-4xl"
          style={{ left: action.x, top: action.y }}
        >
          {action.type === 'hug' ? '💖' : '💋'}
        </motion.div>
      ))}
    </div>
  );
}

function FinalPopup({ onClose }: { onClose: () => void }) {
  const [noPos, setNoPos] = useState({ x: 0, y: 0 });
  const [yesClicked, setYesClicked] = useState(false);

  const handleNoHover = () => {
    setNoPos({
      x: Math.random() * 200 - 100,
      y: Math.random() * 200 - 100
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
    >
      {yesClicked && <Confetti count={200} />}
      
      <motion.div 
        initial={{ scale: 0.8, y: 50 }}
        animate={{ scale: 1, y: 0 }}
        className="glass-card max-w-lg w-full p-10 rounded-3xl border border-pink-500 text-center relative overflow-hidden shadow-[0_0_50px_rgba(255,105,180,0.4)]"
      >
        <div className="absolute inset-0 rounded-3xl border-4 border-pink-500/20 animate-[pulse-glow_2s_infinite]" />
        
        {!yesClicked ? (
          <>
            <h3 className="text-3xl md:text-4xl font-hindi font-bold neon-text mb-4">क्या तुम हमेशा मेरे साथ रहोगी? ❤️</h3>
            <p className="text-gray-300 italic mb-10">Will you stay with me forever?</p>
            
            <div className="flex justify-center gap-8 relative h-16">
              <button 
                onClick={() => setYesClicked(true)}
                className="px-8 py-3 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 font-bold text-xl hover:scale-110 transition-transform shadow-[0_0_15px_rgba(255,105,180,0.5)]"
              >
                हाँ ❤️
              </button>
              
              <motion.button
                animate={{ x: noPos.x, y: noPos.y }}
                onMouseEnter={handleNoHover}
                onClick={handleNoHover}
                className="px-8 py-3 rounded-full bg-gray-800 text-gray-400 font-bold text-xl border border-gray-600 absolute right-[10%]"
              >
                ना 😜
              </motion.button>
            </div>
          </>
        ) : (
          <motion.div 
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="space-y-6"
          >
            <Heart size={80} className="mx-auto text-pink-500" fill="currentColor" />
            <h3 className="text-4xl font-hindi font-bold neon-text leading-relaxed">
              I love you Bitti forever ❤️<br/>
              <span className="text-2xl text-pink-200">तुम सिर्फ मेरी हो! 😘</span>
            </h3>
            <button 
              onClick={onClose}
              className="mt-8 px-6 py-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors text-sm"
            >
              Close
            </button>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}

// Simple CSS Confetti Component
function Confetti({ count = 100 }: { count?: number }) {
  return (
    <div className="fixed inset-0 pointer-events-none z-[150]">
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            x: '50vw', 
            y: '50vh',
            scale: 0
          }}
          animate={{ 
            x: `calc(50vw + ${(Math.random() - 0.5) * 100}vw)`,
            y: `calc(100vh + 100px)`,
            rotate: Math.random() * 360 * 5,
            scale: Math.random() * 1 + 0.5
          }}
          transition={{ 
            duration: Math.random() * 2 + 2, 
            ease: "easeOut"
          }}
          className="absolute w-3 h-3 rounded-sm"
          style={{ 
            backgroundColor: ['#ff69b4', '#a855f7', '#fbbf24', '#ffffff', '#ec4899'][Math.floor(Math.random() * 5)]
          }}
        />
      ))}
    </div>
  );
}

function StarryNight() {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {Array.from({ length: 100 }).map((_, i) => (
        <div 
          key={i}
          className="absolute bg-white rounded-full animate-flicker"
          style={{
            width: Math.random() * 3 + 'px',
            height: Math.random() * 3 + 'px',
            top: Math.random() * 100 + '%',
            left: Math.random() * 100 + '%',
            animationDelay: Math.random() * 2 + 's'
          }}
        />
      ))}
    </div>
  );
}